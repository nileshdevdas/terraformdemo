package oracle.apps.pa.resource.server;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Hashtable;

import oracle.apps.fnd.common.AppsLog;
import oracle.apps.fnd.common.MessageToken;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OAExceptionHelper;
import oracle.apps.fnd.framework.server.OAExceptionUtils;
import oracle.apps.fnd.framework.server.OAViewObjectImpl;
import oracle.apps.pa.finplan.server.ContextRNVOImpl;
import oracle.apps.pa.finplan.server.HGrObjectFrom1VOImpl;
import oracle.apps.pa.finplan.server.HGrParentStrVOImpl;
import oracle.apps.pa.finplan.server.TaskGeneralDetailsVOImpl;
import oracle.apps.pa.resource.server.PACurrencyPickListVOImpl;
import oracle.apps.pa.resource.server.ResourceClassVOImpl;
import oracle.apps.pa.resource.server.ResourceFormatVOImpl;
import oracle.apps.pa.resource.server.TaskPlanTypeDetailsVOImpl;
import oracle.apps.pa.util.StringUtils;
import oracle.apps.pa.util.server.Debug;
import oracle.apps.pa.util.server.PAApplicationModuleImpl;
import oracle.apps.pa.util.server.PAViewObjectImpl;

import oracle.bali.share.collection.ArrayMap;

import oracle.jbo.Row;
import oracle.jbo.domain.Number;
import oracle.jbo.server.ViewLinkImpl;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleConnection;

import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;

public class AssignPlanResAMImpl extends PAApplicationModuleImpl {
    public static final String RCS_ID = "$Header: AssignPlanResAMImpl.java 120.4.12020000.20 2017/05/31 10:39:57 kukonda ship $";

    public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header: AssignPlanResAMImpl.java 120.4.12020000.20 2017/05/31 10:39:57 kukonda ship $", "oracle.apps.pa.resource.server");

    public ContextRNVOImpl getContextRNVO() {
        return (ContextRNVOImpl)findViewObject("ContextRNVO");
    }

    public static void main(String[] paramArrayOfString) {
        launchTester("oracle.apps.pa.finplan.server", "PlElSelectTasksAMLocal");
    }

    public HGrParentStrVOImpl getHGrParentStrVO() {
        return (HGrParentStrVOImpl)findViewObject("HGrParentStrVO");
    }

    public HGrObjectFrom1VOImpl getHGrObjectFrom1VO() {
        return (HGrObjectFrom1VOImpl)findViewObject("HGrObjectFrom1VO");
    }

    public HGrObjectFrom1VOImpl getHGrObjectFrom1VO1() {
        return (HGrObjectFrom1VOImpl)findViewObject("HGrObjectFrom1VO1");
    }

    public ViewLinkImpl getHGrPaToHGrHiVL1() {
        return (ViewLinkImpl)findViewLink("HGrPaToHGrHiVL1");
    }

    public HGrObjectFrom1VOImpl getHGrObjectFrom1VO2() {
        return (HGrObjectFrom1VOImpl)findViewObject("HGrObjectFrom1VO2");
    }

    public ViewLinkImpl getHGrObjFrom1ObjTo1VL1() {
        return (ViewLinkImpl)findViewLink("HGrObjFrom1ObjTo1VL1");
    }

    public void executeHGrParentStrVO() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Entering FpTaskPlanElemAM.executeHGrParentStrVO", 3);
        HGrParentStrVOImpl hGrParentStrVOImpl = getHGrParentStrVO();
        String str1 = (String)oADBTransaction.getValue("budgetVersionId");
        String str2 = (String)oADBTransaction.getValue("resourceListMemberId");
        hGrParentStrVOImpl.setWhereClauseParam(0, str1);
        hGrParentStrVOImpl.setWhereClauseParam(1, str2);
        hGrParentStrVOImpl.executeVO();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Exiting FpTaskPlanElemAM.executeHGrParentStrVO for budget version " + str1, 3);
    }

    public void executeFpAddPlanElemVO() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Entering FpTaskPlanElemAM.executeFpAddPlanElemVO", 3);
        PAViewObjectImpl pAViewObjectImpl = getFpAddPlanElemVO();
        if (!pAViewObjectImpl.isPreparedForExecution())
            pAViewObjectImpl.executeQuery();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Exiting FpTaskPlanElemAM.executeFpAddPlanElemVO", 3);
    }

    public void executeFpRemovePlanElemVO() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Entering FpTaskPlanElemAM.executeFpRemovePlanElemVO", 3);
        PAViewObjectImpl pAViewObjectImpl = getFpRemovePlanElemVO();
        if (!pAViewObjectImpl.isPreparedForExecution())
            pAViewObjectImpl.executeQuery();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Exiting FpTaskPlanElemAM.executeFpRemovePlanElemVO", 3);
    }

    public void executeContextRNVO() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Entering FpTaskPlanElemAM.executeContextRNVO", 3);
        ContextRNVOImpl contextRNVOImpl = getContextRNVO();
        String str1 = (String)oADBTransaction.getValue("budgetVersionId");
        contextRNVOImpl.setWhereClauseParam(0, str1);
        contextRNVOImpl.executeVO();
        String str2 = (contextRNVOImpl.first().getAttribute("CiId") == null) ? null : 
                      contextRNVOImpl.first().getAttribute("CiId").toString();
        if (!StringUtils.isNullOrEmpty(str2)) {
            OAViewObjectImpl oAViewObjectImpl = getFpCIContextInfoVO();
            oAViewObjectImpl.setWhereClauseParams(null);
            oAViewObjectImpl.setWhereClause(null);
            oAViewObjectImpl.setWhereClauseParam(0, str2);
            oAViewObjectImpl.executeQuery();
            oADBTransaction.putValue("ciId", str2);
        }
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Exiting FpTaskPlanElemAM.executeContextRNVO for budget version " + str1, 3);
    }

    public void executeHGrObjectFrom1VO() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Entering FpTaskPlanElemAM.HGrObjectFrom1VO", 3);
        HGrObjectFrom1VOImpl hGrObjectFrom1VOImpl = getHGrObjectFrom1VO();
        String str1 = (String)oADBTransaction.getValue("budgetVersionId");
        String str2 = (String)oADBTransaction.getValue("resourceListMemberId");
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Exiting FpTaskPlanElemAM.HGrObjectFrom1VO for budget version " + str1, 3);
    }

    public void handleApplyEvent() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Entering FpTaskPlanElemAM.handleApplyEvent", 3);
        PAViewObjectImpl pAViewObjectImpl1 = getFpRemovePlanElemVO();
        PAViewObjectImpl pAViewObjectImpl2 = getFpAddPlanElemVO();
        int j = -1;
        int k = -1;
        if (pAViewObjectImpl2 != null)
            j = pAViewObjectImpl2.getRowCount();
        if (pAViewObjectImpl1 != null)
            k = pAViewObjectImpl1.getRowCount();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "  TOTAL_ROWS_SELECTED for addition: [" + j + "]and for deletion[" + k + "]", 3);
        if (k <= 0 && j <= 0) {
            if (i <= 3)
                Debug.write(oADBTransaction, this, "No changes in planning element list", 3);
        } else {
            if (j > 0)
                addResources((OAViewObject)pAViewObjectImpl2, j);
            if (k > 0)
                deleteResources((OAViewObject)pAViewObjectImpl1, k);
        }
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Exiting FpTaskPlanElemAM.handleApplyEvent ", 3);
    }

    public void addResources(OAViewObject paramOAViewObject, int paramInt) {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Entering FpTaskPlanElemAM.addResource for element count" + paramInt, 3);
        String str1 = "begin Pa_Fp_Planning_Transaction_Pub.Add_Planning_Transactions(p_context                     =>       :1,p_project_id                  =>       :2,p_budget_version_id           =>       :3,p_task_elem_version_id_tbl    =>       :4,p_resource_list_member_id_tbl =>       :5,p_skip_duplicates_flag        =>      'Y',x_return_status               =>       :6,x_msg_count                   =>       :7,x_msg_data                    =>       :8); end;";
        OracleCallableStatement oracleCallableStatement = (OracleCallableStatement)oADBTransaction.createCallableStatement(str1, 1);
        String str2 = "";
        int j = 0;
        String str3 = "";
        ContextRNVOImpl contextRNVOImpl = getContextRNVO();
        Row row = contextRNVOImpl.first();
        String str4 = (String)row.getAttribute("PlanClassCode");
        Number number1 = null;
        Number number2 = null;
        Number number3 = null;
        try {
            number1 = new Number(row.getAttribute("ProjectId").toString());
            number2 = new Number(oADBTransaction.getValue("budgetVersionId").toString());
            number3 = new Number(oADBTransaction.getValue("resourceListMemberId").toString());
        } catch (Exception exception) {
        }
        try {
            OracleConnection oracleConnection = (OracleConnection)oADBTransaction.getJdbcConnection();
            ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor("SYSTEM.PA_NUM_TBL_TYPE", (Connection)oracleConnection);
            Number[] arrayOfNumber1 = new Number[paramInt];
            Number[] arrayOfNumber2 = { number3 };
            for (byte b = 0; b < paramInt; b++) {
                if (b == 0) {
                    try {
                        arrayOfNumber1[b] = new Number(paramOAViewObject.first().getAttribute("ElementVersionId").toString());
                    } catch (Exception exception) {
                    }
                } else {
                    try {
                        arrayOfNumber1[b] = new Number(paramOAViewObject.next().getAttribute("ElementVersionId").toString());
                    } catch (Exception exception) {
                    }
                }
                Debug.write(oADBTransaction, this, "adding element [" + b + "] [" + arrayOfNumber1[b].toString() + "]", 3);
            }
            oracleCallableStatement.setString(1, str4);
            oracleCallableStatement.setLong(2, number1.longValue());
            oracleCallableStatement.setLong(3, number2.longValue());
            ARRAY aRRAY1 = new ARRAY(arrayDescriptor, (Connection)oracleConnection, arrayOfNumber1);
            oracleCallableStatement.setARRAY(4, aRRAY1);
            ARRAY aRRAY2 = new ARRAY(arrayDescriptor, (Connection)oracleConnection, arrayOfNumber2);
            oracleCallableStatement.setARRAY(5, aRRAY2);
            oracleCallableStatement.registerOutParameter(6, 12);
            oracleCallableStatement.registerOutParameter(7, 4);
            oracleCallableStatement.registerOutParameter(8, 12);
            Debug.write(oADBTransaction, this, "before calling add api", 3);
            oracleCallableStatement.execute();
            str2 = oracleCallableStatement.getString(6);
            j = oracleCallableStatement.getInt(7);
            str3 = oracleCallableStatement.getString(8);
            Debug.write(oADBTransaction, this, "after calling add api ret stat" + str2, 3);
            OAExceptionUtils.checkErrors(oADBTransaction, j, str2, str3);
        } catch (Exception exception) {
            throw OAException.wrapperException(exception);
        } finally {
            try {
                oracleCallableStatement.close();
            } catch (Exception exception) {
                throw OAException.wrapperException(exception);
            }
        }
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Exiting FpTaskPlanElemAM.addResource", 3);
    }

    public void deleteResources(OAViewObject paramOAViewObject, int paramInt) {
        OADBTransaction oADBTransaction1 = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction1.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction1, this, "Entering FpTaskPlanElemAM.deleteResource for element count" + paramInt, 3);
        String str1 = "begin pa_fp_planning_transaction_pub.delete_planning_transactions (p_context                      =>   :1, p_task_or_res                  =>   :2, p_resource_assignment_tbl      =>   :3, x_return_status                =>   :4, x_msg_count                    =>   :5, x_msg_data                     =>   :6); end;";
        OADBTransaction oADBTransaction2 = getOADBTransaction();
        OracleCallableStatement oracleCallableStatement = (OracleCallableStatement)oADBTransaction2.createCallableStatement(str1, 1);
        String str2 = "";
        int j = 0;
        String str3 = "";
        ContextRNVOImpl contextRNVOImpl = getContextRNVO();
        Row row = contextRNVOImpl.first();
        String str4 = (String)row.getAttribute("PlanClassCode");
        try {
            OracleConnection oracleConnection = (OracleConnection)oADBTransaction2.getJdbcConnection();
            oracleCallableStatement.setString(1, str4);
            oracleCallableStatement.setString(2, "ASSIGNMENT");
            ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor("SYSTEM.PA_NUM_TBL_TYPE", (Connection)oracleConnection);
            Number[] arrayOfNumber = new Number[paramInt];
            for (byte b = 0; b < paramInt; b++) {
                if (b == 0) {
                    try {
                        arrayOfNumber[b] = new Number(paramOAViewObject.first().getAttribute("ResourceAssignmentId").toString());
                    } catch (Exception exception) {
                    }
                } else {
                    try {
                        arrayOfNumber[b] = new Number(paramOAViewObject.next().getAttribute("ResourceAssignmentId").toString());
                    } catch (Exception exception) {
                    }
                }
                Debug.write(oADBTransaction1, this, "adding element [" + b + "] [" + arrayOfNumber[b].toString() + "]", 3);
            }
            ARRAY aRRAY = new ARRAY(arrayDescriptor, (Connection)oracleConnection, arrayOfNumber);
            oracleCallableStatement.setARRAY(3, aRRAY);
            oracleCallableStatement.registerOutParameter(4, 12);
            oracleCallableStatement.registerOutParameter(5, 4);
            oracleCallableStatement.registerOutParameter(6, 12);
            oracleCallableStatement.execute();
            str2 = oracleCallableStatement.getString(4);
            j = oracleCallableStatement.getInt(5);
            str3 = oracleCallableStatement.getString(6);
            OAExceptionUtils.checkErrors(oADBTransaction2, j, str2, str3);
        } catch (Exception exception) {
            throw OAException.wrapperException(exception);
        } finally {
            try {
                oracleCallableStatement.close();
            } catch (Exception exception) {
                throw OAException.wrapperException(exception);
            }
        }
        if (i <= 3)
            Debug.write(oADBTransaction1, this, "Exiting FpTaskPlanElemAM.deleteResource", 3);
    }

    public void getResourceListDetail() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Entering FpTaskPlanElemAM.getResourceListDetail", 3);
        String str1 = "begin SELECT pa_fin_plan_utils.Get_Resource_List_Id(opt.fin_plan_version_id),pa_fin_plan_utils.Get_Fin_Plan_Level_Code(opt.fin_plan_version_id)into :1, :2 from pa_proj_fp_options opt where opt.fin_plan_version_id = :3; end;";
        String str2 = "begin Pa_Planning_Transaction_Utils.Get_Res_Class_Rlm_Ids(p_project_id                   =>    :1, p_resource_list_id             =>    :2, x_people_res_class_rlm_id      =>    :3, x_equip_res_class_rlm_id       =>    :4, x_fin_res_class_rlm_id         =>    :5, x_mat_res_class_rlm_id         =>    :6, x_return_status                =>    :7, x_msg_count                    =>    :8, x_msg_data                     =>    :9 ); end; ";
        String str3 = "begin select PA_FP_GEN_AMOUNT_UTILS.get_src_resource_class_flag(opt.fin_plan_version_id) into :1 from pa_proj_fp_options opt where opt.fin_plan_version_id = :2; end;";
        OracleCallableStatement oracleCallableStatement1 = (OracleCallableStatement)oADBTransaction.createCallableStatement(str1, 1);
        OracleCallableStatement oracleCallableStatement2 = (OracleCallableStatement)oADBTransaction.createCallableStatement(str2, 1);
        OracleCallableStatement oracleCallableStatement3 = (OracleCallableStatement)oADBTransaction.createCallableStatement(str3, 1);
        String str4 = "";
        int j = 0;
        String str5 = "";
        Number number = null;
        try {
            number = new Number(oADBTransaction.getValue("budgetVersionId").toString());
        } catch (Exception exception) {
        }
        ContextRNVOImpl contextRNVOImpl = getContextRNVO();
        String str6 = null;
        if (contextRNVOImpl.isExecuted()) {
            if (contextRNVOImpl.first() != null) {
                str6 = contextRNVOImpl.first().getAttribute("ProjectId").toString();
            } else {
                throw new OAException(" The First row in COntextRNVO is null");
            }
        } else {
            throw new OAException(" The COntextRNVO has not been executed before");
        }
        try {
            oracleCallableStatement1.registerOutParameter(1, 12);
            oracleCallableStatement1.registerOutParameter(2, 12);
            oracleCallableStatement1.setLong(3, number.longValue());
            oracleCallableStatement1.execute();
            Number number1 = new Number(oracleCallableStatement1.getString(1));
            String str7 = oracleCallableStatement1.getString(2);
            if (i <= 3)
                Debug.write(oADBTransaction, this, "FpTaskPlanElemAM.getResourceListDetail Res List Id [" + number1.toString() + "]finplan level[" + str7 + "]", 3);
            oracleCallableStatement2.setLong(1, (new Long(str6)).longValue());
            oracleCallableStatement2.setLong(2, number1.longValue());
            oracleCallableStatement2.registerOutParameter(3, 2);
            oracleCallableStatement2.registerOutParameter(4, 2);
            oracleCallableStatement2.registerOutParameter(5, 2);
            oracleCallableStatement2.registerOutParameter(6, 2);
            oracleCallableStatement2.registerOutParameter(7, 12);
            oracleCallableStatement2.registerOutParameter(8, 4);
            oracleCallableStatement2.registerOutParameter(9, 12);
            oracleCallableStatement2.execute();
            Number number2 = new Number(oracleCallableStatement2.getInt(5));
            if (i <= 3)
                Debug.write(oADBTransaction, this, "FpTaskPlanElemAM.getResourceListDetail Res List Mem Id " + number2.toString(), 3);
            str4 = oracleCallableStatement2.getString(7);
            j = oracleCallableStatement2.getInt(8);
            str5 = oracleCallableStatement2.getString(9);
            oADBTransaction.putValue("resourceListId", number1.toString());
            oADBTransaction.putValue("finplanLevelCode", str7);
            oADBTransaction.putValue("resourceListMemberId", number2.toString());
            oracleCallableStatement3.registerOutParameter(1, 12);
            oracleCallableStatement3.setLong(2, number.longValue());
            oracleCallableStatement3.execute();
            String str8 = oracleCallableStatement3.getString(1);
            oADBTransaction.putValue("resourceClassFlag", str8);
            OAExceptionUtils.checkErrors(oADBTransaction, j, str4, str5);
        } catch (Exception exception) {
            throw OAException.wrapperException(exception);
        } finally {
            try {
                oracleCallableStatement1.close();
                oracleCallableStatement2.close();
                oracleCallableStatement3.close();
                if (i <= 3)
                    Debug.write(oADBTransaction, this, "Exiting FpTaskPlanElemAM.getResourceListDetail", 3);
            } catch (Exception exception) {
                throw OAException.wrapperException(exception);
            }
        }
    }

    public void getUncatResourceListId() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Entering FpTaskPlanElemAM.getUncatResourceListId", 3);
        String str1 = "begin Pa_Fin_Plan_Utils.Get_Uncat_Resource_List_Info(x_resource_list_id            =>    :1, x_resource_list_member_id     =>    :2, x_track_as_labor_flag         =>    :3, x_unit_of_measure             =>    :4, x_return_status               =>    :5, x_msg_count                   =>    :6, x_msg_data                    =>    :7 ); end;  ";
        OracleCallableStatement oracleCallableStatement = (OracleCallableStatement)oADBTransaction.createCallableStatement(str1, 1);
        String str2 = "";
        int j = 0;
        String str3 = "";
        try {
            oracleCallableStatement.registerOutParameter(1, 12);
            oracleCallableStatement.registerOutParameter(2, 2);
            oracleCallableStatement.registerOutParameter(3, 12);
            oracleCallableStatement.registerOutParameter(4, 12);
            oracleCallableStatement.registerOutParameter(5, 12);
            oracleCallableStatement.registerOutParameter(6, 4);
            oracleCallableStatement.registerOutParameter(7, 12);
            oracleCallableStatement.execute();
            Number number = new Number(oracleCallableStatement.getString(1));
            if (i <= 3)
                Debug.write(oADBTransaction, this, "FpTaskPlanElemAM.getUncatResourceListId Uncat Res List Id " + number.toString(), 3);
            str2 = oracleCallableStatement.getString(5);
            j = oracleCallableStatement.getInt(6);
            str3 = oracleCallableStatement.getString(7);
            oADBTransaction.putValue("uncatResourceListId", number.toString());
            OAExceptionUtils.checkErrors(oADBTransaction, j, str2, str3);
        } catch (Exception exception) {
            throw OAException.wrapperException(exception);
        } finally {
            try {
                oracleCallableStatement.close();
                if (i <= 3)
                    Debug.write(oADBTransaction, this, "Exiting FpTaskPlanElemAM.getUncatResourceListId", 3);
            } catch (Exception exception) {
                throw OAException.wrapperException(exception);
            }
        }
    }

    public ArrayMap initializeWebValues(Hashtable paramHashtable) {
        OADBTransaction oADBTransaction = getOADBTransaction();
        String str = (String)paramHashtable.get("budgetVersionId");
        oADBTransaction.putTransientValue("budgetVersionId", str);
        Debug.write(oADBTransaction, this, "initalize web values  [" + str + "]", 3);
        return super.initializeWebValues(paramHashtable);
    }

    public void commitTransaction() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        try {
            oADBTransaction.commit();
        } catch (Exception exception) {
            Debug.write(oADBTransaction, this, "Error trying to commit", 3);
            throw OAException.wrapperException(exception);
        }
    }

    public void emptyTransientVO() {
        PAViewObjectImpl pAViewObjectImpl1 = getFpAddPlanElemVO();
        if (pAViewObjectImpl1 != null)
            pAViewObjectImpl1.remove();
        PAViewObjectImpl pAViewObjectImpl2 = getFpRemovePlanElemVO();
        if (pAViewObjectImpl2 != null)
            pAViewObjectImpl2.remove();
    }

    public PAViewObjectImpl getFpAddPlanElemVO() {
        return (PAViewObjectImpl)findViewObject("FpAddPlanElemVO");
    }

    public PAViewObjectImpl getFpRemovePlanElemVO() {
        return (PAViewObjectImpl)findViewObject("FpRemovePlanElemVO");
    }

    public ResourceClassVOImpl getResourceClassVO() {
        return (ResourceClassVOImpl)findViewObject("ResourceClassVO");
    }

    public OAViewObjectImpl getBudgetVersionVO() {
        return (OAViewObjectImpl)findViewObject("BudgetVersionVO");
    }

    public OAViewObjectImpl getResFormatsVVO() {
        return (OAViewObjectImpl)findViewObject("ResFormatsVVO");
    }

    public ResourceFormatVOImpl getResourceFormatVO() {
        return (ResourceFormatVOImpl)findViewObject("ResourceFormatVO");
    }

    public OAViewObjectImpl getControlFlagVVO() {
        return (OAViewObjectImpl)findViewObject("ControlFlagVVO");
    }

    public OAViewObjectImpl getAssignResVO() {
        return (OAViewObjectImpl)findViewObject("AssignResVO");
    }

    public String getResourceMembers() {
        String str = (String)getValue("ListOfValues");
        if (str == null || str.equals("null")) {
            str = "-1";
        } else {
            str = str + "-1";
        }
        return str;
    }

    public void tableExecute(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8) {
        OADBTransaction oADBTransaction = getOADBTransaction();
        byte b = 3;
        int i = ((AppsLog)getOADBTransaction().getLog()).getLevel();
        OAViewObjectImpl oAViewObjectImpl = getAssignResVO();
        executeHelper(paramString1, paramString2, paramString3, paramString4, paramString5, paramString6, paramString7, paramString8);
        if (i <= b)
            Debug.write(oADBTransaction, this, " planningVO.getQuery() after apply add  select button " + oAViewObjectImpl.getQuery(), b);
        oAViewObjectImpl.executeQuery();
    }

    public String getControlFlag(String paramString) {
        int i = Integer.parseInt(paramString);
        int j = getResourceListId(i);
        String str1 = "" + j;
        OAViewObjectImpl oAViewObjectImpl = getControlFlagVVO();
        oAViewObjectImpl.setWhereClauseParams(null);
        oAViewObjectImpl.setWhereClauseParam(0, str1);
        oAViewObjectImpl.executeQuery();
        Row row = oAViewObjectImpl.first();
        String str2 = "N";
        if (row != null) {
            str2 = (String)row.getAttribute("ControlFlag");
            if (str2 == null)
                str2 = "N";
        }
        return str2;
    }

    public String hasResourceFormats(String paramString) {
        int i = Integer.parseInt(paramString);
        int j = getResourceListId(i);
        String str1 = "" + j;
        OAViewObjectImpl oAViewObjectImpl = getResFormatsVVO();
        oAViewObjectImpl.setWhereClauseParam(0, str1);
        oAViewObjectImpl.executeQuery();
        Row row = oAViewObjectImpl.first();
        String str2 = "0";
        if (row != null) {
            Number number = (Number)row.getAttribute("Counter");
            if (number != null)
                str2 = number.stringValue();
        }
        return str2;
    }

    public String getResourceListId(String paramString) {
        int i = getResourceListId(Integer.parseInt(paramString));
        return "" + i;
    }

    public int getResourceListId(int paramInt) {
        OADBTransaction oADBTransaction = getOADBTransaction();
        byte b = 3;
        int i = ((AppsLog)getOADBTransaction().getLog()).getLevel();
        String str = "BEGIN :1 := pa_fin_plan_utils.get_resource_list_id(:2); END;";
        OracleCallableStatement oracleCallableStatement = (OracleCallableStatement)oADBTransaction.createCallableStatement(str, 1);
        int j = -1;
        try {
            oracleCallableStatement.registerOutParameter(1, 4);
            oracleCallableStatement.setInt(2, paramInt);
            oracleCallableStatement.execute();
            j = oracleCallableStatement.getInt(1);
            oracleCallableStatement.close();
        } catch (SQLException sQLException) {
            try {
                oracleCallableStatement.close();
            } catch (Exception exception) {
                if (i <= b)
                    Debug.write(oADBTransaction, this, "Unable to close the  callable statement", b);
            }
            throw OAException.wrapperException(sQLException);
        }
        return j;
    }

    public void tableQuery(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7) {
        OADBTransaction oADBTransaction = getOADBTransaction();
        byte b = 3;
        int i = ((AppsLog)getOADBTransaction().getLog()).getLevel();
        if (i <= b)
            Debug.write(oADBTransaction, this, "The query is to be made", b);
        OAViewObjectImpl oAViewObjectImpl = getAssignResVO();
        if (i <= b)
            Debug.write(oADBTransaction, this, "Just before Execution " + oAViewObjectImpl.getQuery(), b);
        if (!oAViewObjectImpl.isPreparedForExecution() || "BUDGET".equals(paramString4) || "FORECAST".equals(paramString4)) {
            executeHelper(paramString1, paramString2, paramString3, paramString4, null, paramString6, paramString5, paramString7);
            oAViewObjectImpl.executeQuery();
        }
    }

    public void executeHelper(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8) {
        OAViewObjectImpl oAViewObjectImpl = getAssignResVO();
        int i = Integer.parseInt(paramString7);
        String str1 = "N";
        String str2 = "PROJECT";
        String str3 = "0";
        int j = getResourceListId(i);
        String str4 = "" + j;
        oAViewObjectImpl.setWhereClause(null);
        StringBuffer stringBuffer = new StringBuffer(30);
        if ("-1".equals(paramString1))
            paramString1 = "ALL";
        String str5 = getControlFlag(paramString7);
        str1 = isCbsEnabled(paramString8);
        if (paramString5 != null && !paramString5.equals("")) {
            paramString5 = paramString5.toUpperCase();
            paramString5 = safe(paramString5);
            stringBuffer.append(" and upper(alias) like '%");
            stringBuffer.append(paramString5);
            stringBuffer.append("%'");
        }
        if (str5.equals("N")) {
            str2 = "PROJECT";
            str3 = paramString8;
        } else {
            str2 = "RESOURCE_LIST";
            str3 = str4;
        }
        if (paramString4 != null)
            if (paramString4.equals("TASK_ASSIGNMENT")) {
                if ("N".equals(str1)) {
                    stringBuffer.append(" and not exists(SELECT 'Y' FROM pa_resource_assignments pra WHERE pra.wbs_element_version_id = :8");
                    stringBuffer.append(" and pra.resource_list_member_id=member and pra.ta_display_flag is not null) and WpEligibleFlag = :9");
                }
                String str = stringBuffer.toString();
                if (str.length() > 3)
                    str = str.substring(4);
                oAViewObjectImpl.setWhereClause(str);
                oAViewObjectImpl.setWhereClauseParam(0, str5);
                oAViewObjectImpl.setWhereClauseParam(1, paramString8);
                oAViewObjectImpl.setWhereClauseParam(2, str4);
                oAViewObjectImpl.setWhereClauseParam(3, str2);
                oAViewObjectImpl.setWhereClauseParam(4, str3);
                oAViewObjectImpl.setWhereClauseParam(5, paramString1);
                oAViewObjectImpl.setWhereClauseParam(6, paramString1);
                if ("N".equals(str1)) {
                    oAViewObjectImpl.setWhereClauseParam(7, paramString2);
                    oAViewObjectImpl.setWhereClauseParam(8, "Y");
                }
            } else {
                String str6 = getResourceMembers();
                stringBuffer.append("and  member not in (");
                stringBuffer.append(":8");
                stringBuffer.append(")");
                String str7 = stringBuffer.toString();
                if (str7.length() > 3)
                    str7 = str7.substring(4);
                oAViewObjectImpl.setWhereClause(str7);
                oAViewObjectImpl.setWhereClauseParam(0, str5);
                oAViewObjectImpl.setWhereClauseParam(1, paramString8);
                oAViewObjectImpl.setWhereClauseParam(2, str4);
                oAViewObjectImpl.setWhereClauseParam(3, str2);
                oAViewObjectImpl.setWhereClauseParam(4, str3);
                oAViewObjectImpl.setWhereClauseParam(5, paramString1);
                oAViewObjectImpl.setWhereClauseParam(6, paramString1);
                oAViewObjectImpl.setWhereClauseParam(7, str6);
            }
    }

    public void executeResourceFormat(String paramString1, String paramString2) {
        byte b = 3;
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)getOADBTransaction().getLog()).getLevel();
        if (i <= b) {
            Debug.write(oADBTransaction, this, "Just entered the update  reslist memebers", b);
            Debug.write(oADBTransaction, this, " The res class id " + paramString1, b);
            Debug.write(oADBTransaction, this, " The res list id " + paramString2, b);
        }
        OAViewObject oAViewObject = (OAViewObject)findViewObject("ResourceFormatVO");
        oAViewObject.setWhereClause(null);
        oAViewObject.setWhereClauseParams(null);
        oAViewObject.setWhereClauseParam(0, paramString1);
        oAViewObject.setWhereClauseParam(1, paramString2);
        oAViewObject.setWhereClauseParam(2, paramString1);
        oAViewObject.setWhereClauseParam(3, paramString1);
        oAViewObject.setWhereClauseParam(4, paramString1);
        oAViewObject.executeQuery();
    }

    public void headerQuery(String paramString1, String paramString2) {
        OAViewObjectImpl oAViewObjectImpl = getTaskContextInfoVO();
        if (!oAViewObjectImpl.isPreparedForExecution()) {
            oAViewObjectImpl.setWhereClauseParams(null);
            oAViewObjectImpl.setWhereClauseParam(0, paramString1);
            oAViewObjectImpl.setWhereClauseParam(1, paramString2);
            oAViewObjectImpl.executeQuery();
        }
    }

    public void budgetHeaderQuery(String paramString) {
        OAViewObjectImpl oAViewObjectImpl = getBudgetVersionVO();
        if (!oAViewObjectImpl.isPreparedForExecution()) {
            oAViewObjectImpl.setWhereClauseParams(null);
            oAViewObjectImpl.setWhereClauseParam(0, paramString);
            oAViewObjectImpl.executeQuery();
        }
    }

    public String checkTeamRole(String paramString) {
        OAViewObjectImpl oAViewObjectImpl = getCheckTeamRoleVVO();
        oAViewObjectImpl.setWhereClauseParams(null);
        oAViewObjectImpl.setWhereClauseParam(0, paramString);
        oAViewObjectImpl.executeQuery();
        Row row = oAViewObjectImpl.first();
        Number number1 = new Number(0);
        Number number2 = number1;
        if (row != null) {
            number1 = (Number)row.getAttribute("ProjectCount");
            if (number1 == null)
                number1 = number2;
        }
        byte b = 3;
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)getOADBTransaction().getLog()).getLevel();
        if (i <= b)
            Debug.write(oADBTransaction, this, " The row value returned in Check team role is " + number1.stringValue(), b);
        return number1.stringValue();
    }

    public String getBudgetLines(String paramString1, String paramString2, String paramString3) {
        OADBTransaction oADBTransaction = getOADBTransaction();
        byte b = 3;
        int i = Integer.parseInt(paramString1);
        int j = Integer.parseInt(paramString2);
        int k = Integer.parseInt(paramString3);
        int m = ((AppsLog)getOADBTransaction().getLog()).getLevel();
        String str1 = "BEGIN :1 := pa_fin_plan_utils.Plan_Amount_Exists_Task_Res(:2,:3,:4); END;";
        OracleCallableStatement oracleCallableStatement = (OracleCallableStatement)oADBTransaction.createCallableStatement(str1, 1);
        String str2 = "N";
        try {
            oracleCallableStatement.registerOutParameter(1, 12);
            oracleCallableStatement.setInt(2, i);
            oracleCallableStatement.setInt(3, k);
            oracleCallableStatement.setInt(4, j);
            oracleCallableStatement.execute();
            str2 = oracleCallableStatement.getString(1);
            oracleCallableStatement.close();
        } catch (SQLException sQLException) {
            try {
                oracleCallableStatement.close();
            } catch (Exception exception) {
                if (m <= b)
                    Debug.write(oADBTransaction, this, "Unable to close the  callable statement while retrieveing budget line", b);
            }
            throw OAException.wrapperException(sQLException);
        }
        return str2;
    }

    public String checkPeople(String paramString) {
        byte b = 3;
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)getOADBTransaction().getLog()).getLevel();
        OAViewObjectImpl oAViewObjectImpl = getCheckPeopleVVO();
        oAViewObjectImpl.setWhereClauseParams(null);
        oAViewObjectImpl.setWhereClauseParam(0, paramString);
        oAViewObjectImpl.setWhereClauseParam(1, paramString);
        oAViewObjectImpl.executeQuery();
        Row row = oAViewObjectImpl.first();
        Number number1 = new Number(0);
        Number number2 = number1;
        if (row != null) {
            number1 = (Number)row.getAttribute("PeopleCount");
            if (number1 == null)
                number1 = number2;
        }
        if (i <= b)
            Debug.write(oADBTransaction, this, " The row value returned in Check People is " + number1.stringValue(), b);
        return number1.stringValue();
    }

    public void updateResListMembers(String paramString1, int[] paramArrayOfint, String paramString2, String paramString3, String paramString4) {
        byte b = 3;
        OADBTransaction oADBTransaction = getOADBTransaction();
        String str1 = "N";
        str1 = isCbsEnabled(paramString3);
        int i = ((AppsLog)getOADBTransaction().getLog()).getLevel();
        if (i <= b)
            Debug.write(oADBTransaction, this, "Just entered the update  reslist memebers", b);
        if (i <= b)
            Debug.write(oADBTransaction, this, "taskId Array Length " + paramArrayOfint.length, b);
        int[] arrayOfInt = null;
        Number[] arrayOfNumber1 = null;
        Number[] arrayOfNumber2 = null;
        String str2 = (String)oADBTransaction.getValue("Currency");
        if (paramString1 == null || paramString1.equals(""))
            paramString1 = "TASK_ASSIGNMENT";
        if (i <= b)
            Debug.write(oADBTransaction, this, "structId before ParseInt " + paramString2, b);
        int j = 0;
        if (paramString2 != null && !paramString2.equals(""))
            j = Integer.parseInt(paramString2);
        if (i <= b)
            Debug.write(oADBTransaction, this, "structId ===== " + j, b);
        int k = Integer.parseInt(paramString4);
        if (i <= b)
            Debug.write(oADBTransaction, this, "budgetId ===== " + k, b);
        OracleConnection oracleConnection = null;
        String str3 = "BEGIN pa_fp_planning_transaction_pub.add_planning_transactions (      p_context                      =>  :1     , p_project_id                  =>  :2     , p_task_elem_version_id_tbl    =>  :3     ,p_resource_list_member_id_tbl  =>  :4     , p_struct_elem_version_id      =>  :5     , p_budget_version_id            =>  :6     ,p_project_assignment_id_tbl     => :7     ,p_skip_duplicates_flag   => :8     ,x_return_status             =>  :9     ,x_msg_count              =>  :10     ,x_msg_data             =>  :11   ,p_cbs_element_id_tbl  =>  :12  ";
        if (str2 != null && !str2.equals("")) {
            str3 = str3 + ", p_currency_code_tbl => :13); END;";
        } else {
            str3 = str3 + "); END;";
        }
        String str4 = null;
        int m = 0;
        String str5 = null;
        OracleCallableStatement oracleCallableStatement = null;
        oracleCallableStatement = (OracleCallableStatement)oADBTransaction.createCallableStatement(str3, 1);
        OAViewObjectImpl oAViewObjectImpl = getAssignResVO();
        if (oAViewObjectImpl != null && oracleCallableStatement != null) {
            int n = paramArrayOfint.length;
            int i1 = oAViewObjectImpl.getRowCount();
            oAViewObjectImpl.setRangeStart(1);
            oAViewObjectImpl.setRangeSize(i1);
            Row[] arrayOfRow = oAViewObjectImpl.getAllRowsInRange();
            if (arrayOfRow != null) {
                int i2 = arrayOfRow.length;
                if (i2 != 0) {
                    arrayOfInt = new int[i2];
                    arrayOfNumber1 = new Number[i2];
                    String[] arrayOfString = new String[i2];
                    arrayOfNumber2 = new Number[i2];
                    int[] arrayOfInt1 = getSelectedRows(arrayOfInt, arrayOfNumber1);
                    if (arrayOfInt1 != null && arrayOfInt1.length > 0) {
                        boolean bool = false;
                        String str6 = null;
                        String str7 = "select PA_TASK_UTILS.get_resource_name(:1) from dual";
                        PreparedStatement preparedStatement = null;
                        ResultSet resultSet = null;
                        String str8 = null;
                        preparedStatement = oADBTransaction.createPreparedStatement(str7, 1);
                        for (byte b1 = 0; b1 < i2; b1++) {
                            arrayOfNumber2[b1] = (Number)arrayOfRow[b1].getAttribute("CbsElementId");
                            if ("Y".equals(str1) && arrayOfNumber2[b1] == null) {
                                try {
                                    preparedStatement.setInt(1, arrayOfInt[b1]);
                                    resultSet = preparedStatement.executeQuery();
                                    while (resultSet.next())
                                        str8 = resultSet.getString(1);
                                } catch (SQLException sQLException) {
                                    try {
                                        if (resultSet != null)
                                            resultSet.close();
                                        if (preparedStatement != null)
                                            preparedStatement.close();
                                    } catch (Exception exception) {
                                        throw OAException.wrapperException(exception);
                                    }
                                    throw OAException.wrapperException(sQLException);
                                }
                                if (str6 == null || str6.equalsIgnoreCase("")) {
                                    str6 = str8;
                                } else {
                                    str6 = str6 + ',' + str8;
                                }
                                bool = true;
                            }
                        }
                        try {
                            if (resultSet != null)
                                resultSet.close();
                            if (preparedStatement != null)
                                preparedStatement.close();
                        } catch (Exception exception) {
                            throw OAException.wrapperException(exception);
                        }
                        if (bool) {
                            MessageToken[] arrayOfMessageToken = { new MessageToken("RES_NAME", str6) };
                            throw new OAException("PA", "PA_CBS_WP__COST_CODE_MNDTR", arrayOfMessageToken, (byte)0, null);
                        }
                        if ("Y".equals(str1)) {
                            String str9 = "select resource_list_member_id ,cbs_element_id from pa_resource_assignments where budget_version_id = :1 and project_id = :2 and task_id = :3 ";
                            String str10 = "select proj_element_id ,wbs_number from pa_proj_element_versions where element_version_id = :1";
                            String str11 = "select PA_TASK_UTILS.get_resource_name(:1) from dual";
                            PreparedStatement preparedStatement1 = null;
                            preparedStatement1 = oADBTransaction.createPreparedStatement(str9, 1);
                            PreparedStatement preparedStatement2 = null;
                            preparedStatement2 = oADBTransaction.createPreparedStatement(str10, 1);
                            PreparedStatement preparedStatement3 = null;
                            preparedStatement3 = oADBTransaction.createPreparedStatement(str11, 1);
                            ResultSet resultSet1 = null;
                            ResultSet resultSet2 = null;
                            ResultSet resultSet3 = null;
                            int i3 = paramArrayOfint[0];
                            String str12 = null;
                            String str13 = null;
                            int i4 = 0;
                            int i5 = 0;
                            int i6 = 0;
                            String str14 = null;
                            String str15 = null;
                            String str16 = null;
                            String str17 = null;
                            int i7 = 0;
                            try {
                                preparedStatement2.setInt(1, i3);
                                resultSet2 = preparedStatement2.executeQuery();
                                while (resultSet2.next()) {
                                    i7 = resultSet2.getInt(1);
                                    str12 = resultSet2.getString(2);
                                }
                                preparedStatement1.setString(1, paramString4);
                                preparedStatement1.setString(2, paramString3);
                                preparedStatement1.setInt(3, i7);
                                resultSet1 = preparedStatement1.executeQuery();
                                while (resultSet1.next()) {
                                    i4 = resultSet1.getInt(1);
                                    i5 = resultSet1.getInt(2);
                                    for (byte b2 = 0; b2 < i2; b2++) {
                                        arrayOfNumber2[b2] = (Number)arrayOfRow[b2].getAttribute("CbsElementId");
                                        i6 = arrayOfNumber2[b2].intValue();
                                        if (i6 == i5 && arrayOfInt[b2] == i4) {
                                            try {
                                                preparedStatement3.setInt(1, arrayOfInt[b2]);
                                                resultSet3 = preparedStatement3.executeQuery();
                                                while (resultSet3.next())
                                                    str13 = resultSet3.getString(1);
                                                str17 = (String)arrayOfRow[b2].getAttribute("CostCode");
                                            } catch (SQLException sQLException) {
                                                try {
                                                    if (resultSet1 != null)
                                                        resultSet1.close();
                                                    if (preparedStatement1 != null)
                                                        preparedStatement1.close();
                                                    if (resultSet2 != null)
                                                        resultSet2.close();
                                                    if (preparedStatement2 != null)
                                                        preparedStatement2.close();
                                                    if (resultSet3 != null)
                                                        resultSet3.close();
                                                    if (preparedStatement3 != null)
                                                        preparedStatement3.close();
                                                } catch (Exception exception) {
                                                    throw OAException.wrapperException(exception);
                                                }
                                                throw OAException.wrapperException(sQLException);
                                            }
                                            if (str14 == null || str14.equalsIgnoreCase(""))
                                                str14 = str12;
                                            if (str15 == null || str15.equalsIgnoreCase(""))
                                                str15 = str17;
                                            if (str16 == null || str16.equalsIgnoreCase(""))
                                                str16 = str13;
                                            MessageToken[] arrayOfMessageToken = { new MessageToken("TASK", str14), new MessageToken("COST_CODES", str15), new MessageToken("RES_NAME", str16) };
                                            throw new OAException("PA", "PA_CBS_RESCBS_UNQ_VOILTN", arrayOfMessageToken, (byte)0, null);
                                        }
                                    }
                                }
                            } catch (Exception exception) {
                                throw OAException.wrapperException(exception);
                            }
                        }
                        try {
                            oracleConnection = (OracleConnection)oADBTransaction.getJdbcConnection();
                            ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor("SYSTEM.PA_NUM_TBL_TYPE", (Connection)oracleConnection);
                            if (i <= b)
                                Debug.write(oADBTransaction, this, "The send rray length" + arrayOfInt1.length, b);
                            Number[] arrayOfNumber = (Number[])oADBTransaction.getTransientValue("planResListMemberArray");
                            ARRAY aRRAY1 = new ARRAY(arrayDescriptor, (Connection)oracleConnection, arrayOfInt1);
                            ARRAY aRRAY2 = new ARRAY(arrayDescriptor, (Connection)oracleConnection, paramArrayOfint);
                            ARRAY aRRAY3 = new ARRAY(arrayDescriptor, (Connection)oracleConnection, arrayOfNumber);
                            ARRAY aRRAY4 = new ARRAY(arrayDescriptor, (Connection)oracleConnection, arrayOfNumber2);
                            int i3;
                            for (i3 = 0; i3 < arrayOfNumber.length; i3++) {
                                if (i <= b)
                                    Debug.write(oADBTransaction, this, " the project assignmenet values   befroe call to api" + arrayOfNumber[i3], b);
                            }
                            for (i3 = 0; i3 < paramArrayOfint.length; i3++) {
                                if (i <= b)
                                    Debug.write(oADBTransaction, this, " the task list   befroe call to api" + paramArrayOfint[i3], b);
                            }
                            for (i3 = 0; i3 < arrayOfInt1.length; i3++) {
                                if (i <= b)
                                    Debug.write(oADBTransaction, this, " the resource list ember values  befroe call to api" + arrayOfInt1[i3], b);
                            }
                            oracleCallableStatement.setString(1, paramString1);
                            if (i <= b)
                                Debug.write(oADBTransaction, this, "The context assigned  " + paramString1, b);
                            i3 = 0;
                            try {
                                i3 = Integer.parseInt(paramString3);
                            } catch (NumberFormatException numberFormatException) {
                                throw OAException.wrapperException(numberFormatException);
                            }
                            oracleCallableStatement.setInt(2, i3);
                            if (i <= b)
                                Debug.write(oADBTransaction, this, "proj id assigned  " + i3, b);
                            oracleCallableStatement.setARRAY(3, aRRAY2);
                            if (i <= b)
                                Debug.write(oADBTransaction, this, "Crossed taskLists  ", b);
                            oracleCallableStatement.setARRAY(4, aRRAY1);
                            if (i <= b)
                                Debug.write(oADBTransaction, this, "Crossed resListMemberId", b);
                            if (j != 0) {
                                oracleCallableStatement.setInt(5, j);
                            } else {
                                oracleCallableStatement.setNull(5, 4);
                            }
                            if (i <= b)
                                Debug.write(oADBTransaction, this, "structId assigned" + j, b);
                            oracleCallableStatement.setInt(6, k);
                            if (i <= b)
                                Debug.write(oADBTransaction, this, "Budget version id" + k, b);
                            oracleCallableStatement.setARRAY(7, aRRAY3);
                            if (!paramString1.equals("TASK_ASSIGNMENT")) {
                                oracleCallableStatement.setString(8, "Y");
                                Debug.write(oADBTransaction, this, "8 : Y ", b);

                            } else {
                                oracleCallableStatement.setString(8, "N");
                                Debug.write(oADBTransaction, this, " 8: N ", b);

                            }
                            oracleCallableStatement.registerOutParameter(9, 12, 0, 1);
                            oracleCallableStatement.registerOutParameter(10, 4);
                            oracleCallableStatement.registerOutParameter(11, 12, 0, 4000);
                            oracleCallableStatement.setARRAY(12, aRRAY4);
                            if (str2 != null && !str2.equals("")) {
                                arrayDescriptor = ArrayDescriptor.createDescriptor("SYSTEM.PA_VARCHAR2_15_TBL_TYPE", (Connection)oracleConnection);
                                String[] arrayOfString1 = { str2 };
                                ARRAY aRRAY = new ARRAY(arrayDescriptor, (Connection)oracleConnection, arrayOfString1);
                                oracleCallableStatement.setARRAY(13, aRRAY);
                            }
                            if (i <= b) {
                                Debug.write(oADBTransaction, this, "Execute statement called", b);
                                Debug.write(oADBTransaction, this, "12 : " + aRRAY4, b);
                            }
                            oracleCallableStatement.execute();
                            str4 = oracleCallableStatement.getString(9);
                            m = oracleCallableStatement.getInt(10);
                            str5 = oracleCallableStatement.getString(11);
                            if (i <= b)
                                Debug.write(oADBTransaction, this, "returnStatus : " + str4 + "  messageCount = " + m, b);
                            if (i <= b)
                                Debug.write(oADBTransaction, this, "messageData : " + str5, b);
                            if (!paramString1.equals("TASK_ASSIGNMENT"))
                                handleApplyEvent();
                            OAExceptionUtils.checkErrors(oADBTransaction, m, str4, str5);
                            oADBTransaction.commit();
                            if (i <= b)
                                Debug.write(oADBTransaction, this, "Commit called on API", b);
                            OAViewObjectImpl oAViewObjectImpl1 = getAssignResVO();
                            String str = (String)oADBTransaction.getValue("IsEndeca");
                            if (str == null && oAViewObjectImpl1 != null)
                                oAViewObjectImpl1.executeQuery();
                        } catch (SQLException sQLException) {
                            if (i <= b) {
                                Debug.write(oADBTransaction, this, "Error in executing Planning transaction API", b);
                                Debug.write(oADBTransaction, this, sQLException.getMessage(), b);
                            }
                            if (sQLException.getErrorCode() == 1)
                                throw new OAException("PA", "PA_CBS_RESCBS_UNQ_VOILTN", null, (byte)0, null);
                            throw OAException.wrapperException(sQLException);
                        } catch (Exception exception) {
                            if (i <= b) {
                                Debug.write(oADBTransaction, this, "Error in Defining Arrays", b);
                                Debug.write(oADBTransaction, this, exception.getMessage(), b);
                            }
                            throw OAException.wrapperException(exception);
                        } finally {
                            try {
                                if (i <= b)
                                    Debug.write(oADBTransaction, this, "About to close callable statement... ", b);
                                oracleCallableStatement.close();
                            } catch (Exception exception) {
                                if (i <= b)
                                    Debug.write(oADBTransaction, this, "Could NOT close callable statement / connection ! ", b);
                            }
                        }
                        if (i <= b)
                            Debug.write(oADBTransaction, this, "Leaving updateResListMembers ! ", b);
                    }
                } else if (i <= b) {
                    Debug.write(oADBTransaction, this, "PlanningResourceClasses Vo has no rows", b);
                }
            } else if (i <= b) {
                Debug.write(oADBTransaction, this, "PlanningResourceClasses Vo has no rows", b);
            }
        } else if (i <= b) {
            Debug.write(oADBTransaction, this, "PlanningResourceClasses is null", b);
        }
    }

    public void budgetTaskQuery(String paramString) {
        OAViewObjectImpl oAViewObjectImpl = getBudgetTaskVO();
        oAViewObjectImpl.setWhereClauseParams(null);
        oAViewObjectImpl.setWhereClauseParam(0, paramString);
        oAViewObjectImpl.setWhereClauseParam(1, paramString);
        oAViewObjectImpl.executeQuery();
    }

    public int[] getSelectedRows(int[] paramArrayOfint, Number[] paramArrayOfNumber) {
        byte b = 5;
        int[] arrayOfInt = null;
        Number[] arrayOfNumber = null;
        String str = "";
        int i = ((AppsLog)getOADBTransaction().getLog()).getLevel();
        OADBTransaction oADBTransaction = getOADBTransaction();
        OAViewObjectImpl oAViewObjectImpl = getAssignResVO();
        if (oAViewObjectImpl != null) {
            Row[] arrayOfRow = oAViewObjectImpl.getAllRowsInRange();
            if (arrayOfRow != null) {
                int j = arrayOfRow.length;
                if (j != 0) {
                    byte b1 = 0;
                    Number number = new Number(-1);
                    int k;
                    for (k = 0; k < j; k++) {
                        b1++;
                        if (i <= b)
                            Debug.write(oADBTransaction, this, " the index " + k + "  is selected", b);
                        Number number1 = (Number)arrayOfRow[k].getAttribute("ResourceListMemberId");
                        if (i <= b)
                            Debug.write(oADBTransaction, this, " the Number value is " + number1, b);
                        if (number1 != null) {
                            paramArrayOfint[k] = number1.intValue();
                            Number number2 = (Number)arrayOfRow[k].getAttribute("IncurByRoleId");
                            if (number2 == null) {
                                number2 = number;
                                if (i <= b)
                                    Debug.write(oADBTransaction, this, " the GMISS NUM value being substituted is " + number2, b);
                            }
                            paramArrayOfNumber[k] = number2;
                            if (i <= b)
                                Debug.write(oADBTransaction, this, " the list member Id's  the incurred by role" + paramArrayOfint[k], b);
                        }
                    }
                    if (b1 > 0) {
                        arrayOfInt = new int[b1];
                        arrayOfNumber = new Number[b1];
                        if (i <= b)
                            Debug.write(oADBTransaction, this, " the row count " + b1, b);
                        k = paramArrayOfint.length;
                        byte b2 = 0;
                        for (byte b3 = 0; b3 < k; b3++) {
                            if (paramArrayOfint[b3] > 0) {
                                arrayOfInt[b2] = paramArrayOfint[b3];
                                arrayOfNumber[b2] = paramArrayOfNumber[b3];
                                str = str + arrayOfInt[b2] + ",";
                                if (i <= b)
                                    Debug.write(oADBTransaction, this, " the project memebr  array is" + arrayOfNumber[b2], b);
                                if (i <= b)
                                    Debug.write(oADBTransaction, this, " the relist array is" + arrayOfInt[b2], b);
                                b2++;
                            }
                        }
                    }
                }
            }
        }
        if (getValue("ListOfValues") != null && !getValue("ListOfValues").equals("")) {
            String str1 = (String)getValue("ListOfValues");
            str1 = str1 + str;
            putValue("ListOfValues", str1);
        } else {
            putValue("ListOfValues", str);
        }
        oADBTransaction.putTransientValue("planResListMemberArray", arrayOfNumber);
        return arrayOfInt;
    }

    public static String safe(String paramString) {
        String str = "";
        StringBuffer stringBuffer = new StringBuffer("");
        for (byte b = 0; b < paramString.length(); b++) {
            if (paramString.charAt(b) == '\'')
                stringBuffer.append(paramString.charAt(b));
            stringBuffer.append(paramString.charAt(b));
        }
        str = "" + stringBuffer + "";
        return str;
    }

    public PAViewObjectImpl getPlanningResTeamRolesVO() {
        return (PAViewObjectImpl)findViewObject("PlanningResTeamRolesVO");
    }

    public OAViewObjectImpl getCheckPeopleVVO() {
        return (OAViewObjectImpl)findViewObject("CheckPeopleVVO");
    }

    public OAViewObjectImpl getCheckTeamRoleVVO() {
        return (OAViewObjectImpl)findViewObject("CheckTeamRoleVVO");
    }

    public OAViewObjectImpl getFpCIContextInfoVO() {
        return (OAViewObjectImpl)findViewObject("FpCIContextInfoVO");
    }

    public OAViewObjectImpl getBudgetTaskVO() {
        return (OAViewObjectImpl)findViewObject("BudgetTaskVO");
    }

    public OAViewObjectImpl getTaskContextInfoVO() {
        return (OAViewObjectImpl)findViewObject("TaskContextInfoVO");
    }

    public void setTxnStateDirty() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3) {
            Debug.write(oADBTransaction, this, "-------Entering FpTaskPlanElemAM.setTxnStateDirty---------", 3);
            Debug.write(oADBTransaction, this, "-------Setting transaction Dirty---------", 3);
        }
        oADBTransaction.setPlsqlState((byte)2);
        if (i <= 3)
            Debug.write(oADBTransaction, this, "-------Leaving FpTaskPlanElemAM.setTxnStateDirty---------", 3);
    }

    public OAViewObjectImpl getPaFpLookupVO() {
        return (OAViewObjectImpl)findViewObject("PaFpLookupVO");
    }

    public void executePaLookupVO() {
        OAViewObjectImpl oAViewObjectImpl = getPaFpLookupVO();
        OADBTransaction oADBTransaction = getOADBTransaction();
        String str1 = (String)oADBTransaction.getValue("resourceListId");
        String str2 = (String)oADBTransaction.getValue("uncatResourceListId");
        String str3 = (String)oADBTransaction.getValue("resourceClassFlag");
        String str4 = "PA_FP_PLAN_ELEM";
        String str5 = "ADD_RES";
        Debug.write(oADBTransaction, this, "Comparing RLID budget [" + str1 + "] uncat [" + str2 + "]", 3);
        if ("N".equalsIgnoreCase(str3)) {
            if (!str2.equalsIgnoreCase(str1)) {
                oAViewObjectImpl.setWhereClause(null);
                oAViewObjectImpl.setWhereClause("lookup_type = :1 and lookup_code = :2");
                oAViewObjectImpl.setWhereClauseParam(0, str4);
                oAViewObjectImpl.setWhereClauseParam(1, str5);
                Debug.write(oADBTransaction, this, "Inside if", 3);
            }
        } else if (str2.equalsIgnoreCase(str1)) {
            oAViewObjectImpl.setWhereClause(null);
            oAViewObjectImpl.setWhereClause("lookup_type = :1 and lookup_code <> :2");
            oAViewObjectImpl.setWhereClauseParam(0, str4);
            oAViewObjectImpl.setWhereClauseParam(1, str5);
            Debug.write(oADBTransaction, this, "Inside if", 3);
        } else {
            oAViewObjectImpl.setWhereClause(null);
            oAViewObjectImpl.setWhereClause("lookup_type = :1");
            oAViewObjectImpl.setWhereClauseParam(0, str4);
            Debug.write(oADBTransaction, this, "Inside Else", 3);
        }
        oAViewObjectImpl.executeQuery();
    }

    public OAViewObjectImpl getPaFpLookupVO1() {
        return (OAViewObjectImpl)findViewObject("PaFpLookupVO1");
    }

    public void executePaLookupVOForGlobalDropDown() {
        OAViewObjectImpl oAViewObjectImpl = getPaFpLookupVO1();
        OADBTransaction oADBTransaction = getOADBTransaction();
        String str1 = (String)oADBTransaction.getValue("resourceListId");
        String str2 = (String)oADBTransaction.getValue("uncatResourceListId");
        String str3 = (String)oADBTransaction.getValue("finplanLevelCode");
        String str4 = "PA_FP_GBL_ACT_LIST";
        String str5 = "";
        Debug.write(oADBTransaction, this, "Planning Level is " + str3, 3);
        if ("T".equals(str3)) {
            if (str2.equalsIgnoreCase(str1)) {
                oAViewObjectImpl.setWhereClause(null);
                oAViewObjectImpl.setWhereClause("lookup_type = :1 and lookup_code = 'ADD_ALL_TOP_TSK' ");
                oAViewObjectImpl.setWhereClauseParam(0, str4);
                Debug.write(oADBTransaction, this, "Inside 1", 3);
            } else {
                oAViewObjectImpl.setWhereClause(null);
                oAViewObjectImpl.setWhereClause("lookup_type = :1 and lookup_code IN ('ADD_ALL_TOP_TSK' , 'ADD_ALL_RES_TOP_TSK') ");
                oAViewObjectImpl.setWhereClauseParam(0, str4);
                Debug.write(oADBTransaction, this, "Inside 2", 3);
            }
        } else if ("L".equals(str3)) {
            if (str2.equalsIgnoreCase(str1)) {
                oAViewObjectImpl.setWhereClause(null);
                oAViewObjectImpl.setWhereClause("lookup_type = :1 and lookup_code IN ('ADD_ALL_TOP_TSK' , 'ADD_ALL_LOW_TSK')");
                oAViewObjectImpl.setWhereClauseParam(0, str4);
                Debug.write(oADBTransaction, this, "Inside 3", 3);
            } else {
                oAViewObjectImpl.setWhereClause(null);
                oAViewObjectImpl.setWhereClause("lookup_type = :1 ");
                oAViewObjectImpl.setWhereClauseParam(0, str4);
                Debug.write(oADBTransaction, this, "Inside 4", 3);
            }
        }
        if (!oAViewObjectImpl.isExecuted())
            oAViewObjectImpl.executeQuery();
    }

    public void executeGlobalActionsdropdown() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        int i = ((AppsLog)oADBTransaction.getLog()).getLevel();
        if (i <= 3)
            Debug.write(oADBTransaction, this, "Entering FpTaskPlanElemAM.getUncatResourceListId", 3);
        String str1 = "begin  Pa_fp_planning_transaction_pub.Create_Default_Task_Plan_Txns(p_budget_version_id           =>    :1, P_version_plan_level_code     =>    :2, p_calling_context             =>    :3, p_add_all_resources_flag      =>    :4, x_return_status               =>    :5, x_msg_count                   =>    :6, x_msg_data                    =>    :7 ); end;  ";
        OracleCallableStatement oracleCallableStatement = (OracleCallableStatement)oADBTransaction.createCallableStatement(str1, 1);
        String str2 = "";
        int j = 0;
        String str3 = "";
        String str4 = oADBTransaction.getValue("budgetVersionId").toString();
        String str5 = oADBTransaction.getValue("AddTaskAtLevel").toString();
        String str6 = oADBTransaction.getValue("addAllResourcesFlag").toString();
        try {
            oracleCallableStatement.setString(1, str4);
            oracleCallableStatement.setString(2, str5);
            oracleCallableStatement.setString(3, "SELECT_TASKS");
            oracleCallableStatement.setString(4, str6);
            oracleCallableStatement.registerOutParameter(5, 12);
            oracleCallableStatement.registerOutParameter(6, 4);
            oracleCallableStatement.registerOutParameter(7, 12);
            oracleCallableStatement.execute();
            if (i <= 3)
                Debug.write(oADBTransaction, this, "Executed global actions dropdown ", 3);
            str2 = oracleCallableStatement.getString(5);
            j = oracleCallableStatement.getInt(6);
            str3 = oracleCallableStatement.getString(7);
            OAExceptionUtils.checkErrors(oADBTransaction, j, str2, str3);
            commitTransaction();
        } catch (Exception exception) {
            throw OAException.wrapperException(exception);
        } finally {
            try {
                oracleCallableStatement.close();
                if (i <= 3)
                    Debug.write(oADBTransaction, this, "Exiting FpTaskPlanElemAM.getUncatResourceListId", 3);
            } catch (Exception exception) {
                throw OAException.wrapperException(exception);
            }
        }
    }

    public OAViewObjectImpl getPaTipShowVO() {
        return (OAViewObjectImpl)findViewObject("PaTipShowVO");
    }

    public void executeCreateTipVO() {
        OAViewObjectImpl oAViewObjectImpl = getPaTipShowVO();
        if (oAViewObjectImpl != null) {
            if (oAViewObjectImpl.getFetchedRowCount() == 0) {
                oAViewObjectImpl.setMaxFetchSize(0);
                oAViewObjectImpl.insertRow(oAViewObjectImpl.createRow());
                OARow oARow = (OARow)oAViewObjectImpl.first();
            }
            oAViewObjectImpl.first().setAttribute("ShowTip1", Boolean.FALSE);
            oAViewObjectImpl.first().setAttribute("ShowTip2", Boolean.FALSE);
            oAViewObjectImpl.first().setAttribute("ShowTip3", Boolean.FALSE);
            oAViewObjectImpl.first().setAttribute("ShowTip4", Boolean.FALSE);
            oAViewObjectImpl.first().setAttribute("ShowTip5", Boolean.FALSE);
            oAViewObjectImpl.first().setAttribute("ShowTip6", Boolean.FALSE);
        }
    }

    public OAViewObjectImpl getPaDummyPopListVO() {
        return (OAViewObjectImpl)findViewObject("PaDummyPopListVO");
    }

    public void executeDummyTipVO() {
        OAViewObjectImpl oAViewObjectImpl = getPaDummyPopListVO();
        if (!oAViewObjectImpl.isExecuted())
            oAViewObjectImpl.executeQuery();
    }

    public void setTipTexts() {
        OADBTransaction oADBTransaction = getOADBTransaction();
        String str1 = (String)oADBTransaction.getValue("resourceListId");
        String str2 = (String)oADBTransaction.getValue("uncatResourceListId");
        OAViewObjectImpl oAViewObjectImpl1 = getPaTipShowVO();
        OAViewObjectImpl oAViewObjectImpl2 = getPaDummyPopListVO();
        oAViewObjectImpl1.first().setAttribute("ShowTip1", Boolean.FALSE);
        oAViewObjectImpl1.first().setAttribute("ShowTip2", Boolean.FALSE);
        oAViewObjectImpl1.first().setAttribute("ShowTip3", Boolean.FALSE);
        oAViewObjectImpl1.first().setAttribute("ShowTip4", Boolean.FALSE);
        oAViewObjectImpl1.first().setAttribute("ShowTip5", Boolean.FALSE);
        oAViewObjectImpl1.first().setAttribute("ShowTip6", Boolean.FALSE);
        if ("ADD_ALL_LOW_TSK".equals(oADBTransaction.getValue("tipAction").toString())) {
            if (!str2.equalsIgnoreCase(str1)) {
                oAViewObjectImpl1.first().setAttribute("ShowTip1", Boolean.TRUE);
            } else {
                oAViewObjectImpl1.first().setAttribute("ShowTip5", Boolean.TRUE);
            }
        } else if ("ADD_ALL_RES_LOW_TSK".equals(oADBTransaction.getValue("tipAction").toString())) {
            oAViewObjectImpl1.first().setAttribute("ShowTip2", Boolean.TRUE);
        } else if ("ADD_ALL_TOP_TSK".equals(oADBTransaction.getValue("tipAction").toString())) {
            if (!str2.equalsIgnoreCase(str1)) {
                oAViewObjectImpl1.first().setAttribute("ShowTip3", Boolean.TRUE);
            } else {
                oAViewObjectImpl1.first().setAttribute("ShowTip6", Boolean.TRUE);
            }
        } else if ("ADD_ALL_RES_TOP_TSK".equals(oADBTransaction.getValue("tipAction").toString())) {
            oAViewObjectImpl1.first().setAttribute("ShowTip4", Boolean.TRUE);
        }
        oAViewObjectImpl2.first().setAttribute("Code", oADBTransaction.getValue("tipAction").toString());
    }

    public void initiateMultiSelectVO() {
        OAViewObjectImpl oAViewObjectImpl = getAssignResVO();
        if (oAViewObjectImpl.getFetchedRowCount() == 0)
            oAViewObjectImpl.setMaxFetchSize(0);
    }

    public TaskPlanTypeDetailsVOImpl getTaskPlanTypeDetailsVO() {
        return (TaskPlanTypeDetailsVOImpl)findViewObject("TaskPlanTypeDetailsVO");
    }

    public TaskGeneralDetailsVOImpl getTaskGeneralDetailsVO() {
        return (TaskGeneralDetailsVOImpl)findViewObject("TaskGeneralDetailsVO");
    }

    public PACurrencyPickListVOImpl getPACurrencyPickListVO() {
        return (PACurrencyPickListVOImpl)findViewObject("PACurrencyPickListVO");
    }

    public void executeTaskPlanTypeDetailsVO(String paramString1, String paramString2) {
        OADBTransaction oADBTransaction = getOADBTransaction();
        TaskPlanTypeDetailsVOImpl taskPlanTypeDetailsVOImpl = getTaskPlanTypeDetailsVO();
        if (taskPlanTypeDetailsVOImpl != null && !taskPlanTypeDetailsVOImpl.isPreparedForExecution()) {
            taskPlanTypeDetailsVOImpl.clearCache();
            taskPlanTypeDetailsVOImpl.setWhereClause(null);
            taskPlanTypeDetailsVOImpl.setWhereClauseParams(null);
            taskPlanTypeDetailsVOImpl.setWhereClauseParam(0, paramString1);
            taskPlanTypeDetailsVOImpl.setWhereClauseParam(1, paramString2);
            taskPlanTypeDetailsVOImpl.setWhereClauseParam(2, paramString1);
            taskPlanTypeDetailsVOImpl.executeQuery();
        }
    }

    public void loadTaskDetails(String paramString1, String paramString2) {
        OADBTransaction oADBTransaction = getOADBTransaction();
        oADBTransaction.putValue("paProjectId", paramString1);
        StringBuffer stringBuffer = new StringBuffer(" project_id = :1 and proj_element_id = :2");
        TaskGeneralDetailsVOImpl taskGeneralDetailsVOImpl = getTaskGeneralDetailsVO();
        if (taskGeneralDetailsVOImpl == null)
            throw new OAException("FpEditPlanAMImpl.loadMassTasksVO: TaskDetailsVO is NULL ");
        taskGeneralDetailsVOImpl.clearCache();
        taskGeneralDetailsVOImpl.setWhereClause(null);
        taskGeneralDetailsVOImpl.setWhereClauseParams(null);
        taskGeneralDetailsVOImpl.setWhereClause(stringBuffer.toString());
        taskGeneralDetailsVOImpl.setWhereClauseParam(0, paramString1);
        taskGeneralDetailsVOImpl.setWhereClauseParam(1, paramString2);
        if (!taskGeneralDetailsVOImpl.isPreparedForExecution()) {
            taskGeneralDetailsVOImpl.executeQuery();
            taskGeneralDetailsVOImpl.getRowCount();
        }
    }

    public void assignResourceToTask(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6) {
        OADBTransaction oADBTransaction = getOADBTransaction();
        OracleConnection oracleConnection = (OracleConnection)oADBTransaction.getJdbcConnection();
        if (oADBTransaction.isLoggingEnabled(3))
            Debug.write(oADBTransaction, this, "ENTERED PlanningElementsCommonVOImpl.assignResourceToTask()", 3);
        boolean bool1 = false;
        byte b = 0;
        String str1 = "newRlmId";
        boolean bool2 = true;
        Object[] arrayOfObject1 = new Object[1];
        Object[] arrayOfObject2 = new Object[1];
        Object[] arrayOfObject3 = new Object[1];
        Number[] arrayOfNumber = new Number[1];
        arrayOfObject1[b] = paramString5;
        arrayOfObject2[b] = paramString4;
        arrayOfObject3[b] = paramString6;
        if (oADBTransaction.isLoggingEnabled(3)) {
            Debug.write(oADBTransaction, this, "retrieved [" + b + "]," + "--newEvId=" + oADBTransaction.getValue("newEvId") + "--newRlmId=" + oADBTransaction.getValue("newRlmId") + "--newTxnCur=" + oADBTransaction.getValue("newTxnCur"), 3);
            b++;
        }
        String str2 = "begin pa_planning_element_utils.add_new_resource_assignments(p_context                      => :1,p_project_id                   => :2,p_budget_version_id            => :3,p_task_elem_version_id_tbl     => :4,p_resource_list_member_id_tbl  => :5,p_currency_code_tbl            => :6,x_return_status                => :7,x_msg_count                    => :8,x_msg_data                     => :9, p_cbs_element_id_tbl  =>  :10); end;";
        CallableStatement callableStatement = oADBTransaction.createCallableStatement(str2, 1);
        int i = Integer.parseInt(paramString2);
        int j = Integer.parseInt(paramString3);
        try {
            ArrayDescriptor arrayDescriptor1 = ArrayDescriptor.createDescriptor("SYSTEM.PA_NUM_TBL_TYPE", (Connection)oracleConnection);
            ArrayDescriptor arrayDescriptor2 = ArrayDescriptor.createDescriptor("SYSTEM.PA_VARCHAR2_15_TBL_TYPE", (Connection)oracleConnection);
            callableStatement.setString(1, paramString1);
            callableStatement.setInt(2, i);
            callableStatement.setInt(3, j);
            ARRAY aRRAY1 = new ARRAY(arrayDescriptor1, (Connection)oracleConnection, arrayOfObject1);
            ((OracleCallableStatement)callableStatement).setARRAY(4, aRRAY1);
            ARRAY aRRAY2 = new ARRAY(arrayDescriptor1, (Connection)oracleConnection, arrayOfObject2);
            ((OracleCallableStatement)callableStatement).setARRAY(5, aRRAY2);
            ARRAY aRRAY3 = new ARRAY(arrayDescriptor2, (Connection)oracleConnection, arrayOfObject3);
            ((OracleCallableStatement)callableStatement).setARRAY(6, aRRAY3);
            callableStatement.registerOutParameter(7, 12);
            callableStatement.registerOutParameter(8, 4);
            callableStatement.registerOutParameter(9, 12);
            ARRAY aRRAY4 = new ARRAY(arrayDescriptor1, (Connection)oracleConnection, arrayOfNumber);
            ((OracleCallableStatement)callableStatement).setARRAY(10, aRRAY4);
            if (oADBTransaction.isLoggingEnabled(3))
                Debug.write(oADBTransaction, this, "before execute", 3);
            callableStatement.execute();
            if (oADBTransaction.isLoggingEnabled(3))
                Debug.write(oADBTransaction, this, "after execute", 3);
            String str3 = callableStatement.getString(7);
            int k = callableStatement.getInt(8);
            String str4 = callableStatement.getString(9);
            OAExceptionHelper oAExceptionHelper = new OAExceptionHelper();
            oAExceptionHelper.checkErrors(oADBTransaction, k, str3, str4);
            if ("S".equals(str3)) {
                oADBTransaction.putValue("refreshAfterCommit", "Y");
                oADBTransaction.commit();
                oADBTransaction.putValue("refreshAfterCommit", "N");
            }
            if (getValue("ListOfValues") != null && !getValue("ListOfValues").equals("")) {
                String str = (String)getValue("ListOfValues");
                str = str + paramString4 + ",";
                putValue("ListOfValues", str);
            } else {
                putValue("ListOfValues", paramString4 + ",");
            }
        } catch (OAException oAException) {
            throw oAException;
        } catch (Exception exception) {
            throw OAException.wrapperException(exception);
        } finally {
            try {
                callableStatement.close();
            } catch (OAException oAException) {
                throw oAException;
            } catch (Exception exception) {
                throw OAException.wrapperException(exception);
            }
        }
        if (oADBTransaction.isLoggingEnabled(3))
            Debug.write(oADBTransaction, this, "EXITED PlanningElementsCommonVOImpl.assignResourceToTask()", 3);
    }
}
