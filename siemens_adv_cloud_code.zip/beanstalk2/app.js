var port = process.env.PORT || 3000;
var http = require("http");
var server = http.createServer(function(req,res){
    res.write("Hello World ~!!!!!!~");
    res.end();
});
server.listen(port);

