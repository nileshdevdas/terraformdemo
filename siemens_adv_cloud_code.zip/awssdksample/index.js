var AWS = require("aws-sdk");
var ddb = new AWS.DynamoDB({
    region: 'ap-south-1'
});

var S3 = new AWS.S3({});

S3.listBuckets({}, function (err, resp) {
    if (err)
        console.log(err);
    else {
        resp.Buckets.forEach((each) => {
            console.log(each.Name);
        });
    }
});

ddb.putItem({}, (err, function(){
    // duynamo db 
}));